<head>
    <title>Tính tiền Karaoke</title>
    <style>
        td
        {
            padding-right: 10px;
        }
    </style>
</head>
<body>
    <?php 
        if(isset($_POST["submit"]))
        {
            $bd = $_POST["bd"];
            $kt = $_POST["kt"];
            if(is_numeric($bd) && is_numeric($kt))
            {
                if(($bd >= 0 && $bd <= 24) && ($kt >= 0 && $kt <= 24))
                {
                    if($kt > $bd)
                    {
                        if(($bd >= 10) && ($bd < 17))
                        {
                            $kq = ($kt - $bd) * 20000;
                        }
                        else if(($bd >= 17) && ($bd < 24))
                        {
                            $kq = ($kt - $bd) * 45000;
                        }
                        else
                        {
                            $kq = "Giờ nghỉ!";
                        }
                    }
                    else
                    {
                        $msg = "Giờ kết thúc phải > giờ bắt đầu";
                    }
                }
                else
                {
                    $msg = "Giờ phải >= 0 và <= 24!";
                }
            }
            else
            {
                $msg = "Không được để trống!";
            }
        }
    ?>
    <div>
        <div style="color: white;background-color: #008B8E;font-size: 30px; width: 25%;text-align: center;">TÍNH TIỀN KARAOKE</div>
        <div style="background-color: #03B1B2;width: 25%">
            <form method="post" action="#">
                <table>
                    <tr>
                        <td>Giờ bắt đầu:</td>
                        <td><input type="number" name="bd" value="<?php if(isset($bd)) {echo $bd;} ?>"></td>
                        <td>(h)</td>
                    </tr>
                    <tr>
                        <td>Giờ kết thúc:</td>
                        <td><input type="number" name="kt" value="<?php if(isset($kt)) {echo $kt;} ?>"></td>
                        <td>(h)</td>
                    </tr>
                    <tr>
                        <td>Tiền thanh toán:</td>
                        <td><input style="background-color: #FFFEE6;color: green" type="text" name="kq" readonly value="<?php if(isset($kq)) {echo $kq;} ?>"></td>
                        <td>(VNĐ)</td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align: center;">
                            <input type="submit" name="submit" value="Tính tiền">
                        </td>
                    </tr>
                </table>
            </form>
            <div style="color: red;"><?php if(isset($msg)) {echo $msg;}?></div>
        </div>
    </div>
</body>