<head>
    <title>Tính chu vi và diện tích hình tròn</title>
    <style>
        td
        {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <?php 
        define("PI",3.14);
        if(isset($_POST["submit"]))
        {
            $bk = $_POST["bk"];
            if(is_numeric($bk))
            {
                if($bk > 0)
                {
                    $cv = 2 * PI * $bk;
                    $dt = PI * ($bk * $bk);
                }
                else
                {
                    $msg = "Bán kính phải > 0";
                }
            }
            else
            {
                $msg = "Chỉ được nhập số!";
            }
        }
    ?>
    <div>
        <div style="color: darkred;background-color: #FDDA79;font-size: 24px; width: 20%;text-align: center;">DIỆN TÍCH và CHU VI HÌNH TRÒN</div>
        <div style="background-color: #FEFBD8;width: 20%">
            <form method="post" action="#">
                <table>
                    <tr>
                        <td>Bán kính:</td>
                        <td><input type="number" step=any name="bk" value="<?php if(isset($bk)) {echo $bk;} ?>"></td>
                    </tr>
                    <tr>
                        <td>Diện tích:</td>
                        <td><input type="text" readonly name="dt" style="background-color: #FFDAD5;" value="<?php if(isset($dt)) {echo $dt;}?>"></td>
                    </tr>
                    <tr>
                        <td>Chu vi:</td>
                        <td><input type="text" readonly name="cv" style="background-color: #FFDAD5;" value="<?php if(isset($cv)) {echo $cv;}?>"></td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align: center;">
                            <input type="submit" name="submit" value="Tính">
                        </td>
                    </tr>
                </table>
            </form>
            <div style="color: red;"><?php if(isset($msg)) {echo $msg;}?></div>
        </div>
    </div>
</body>