<head>
    <title>Thanh toán tiền điện</title>
    <style>
        td
        {
            padding-right: 25px;
        }
    </style>
</head>
<body>
    <?php 
        if(isset($_POST["submit"]))
        {
            $name = $_POST["name"];
            $cs_old = $_POST["cs_old"];
            $cs_new = $_POST["cs_new"];
            $dg = $_POST["dg"];
            if(is_numeric($cs_old) && is_numeric($cs_new) && is_numeric($dg))
            {
                if($cs_old >= 0 && $cs_new >= 0 && $dg >= 0)
                {
                    if($cs_new >= $cs_old)
                    {
                        $total = ($cs_new - $cs_old) * $dg;
                    }
                    else
                    {
                        $msg = "Chỉ số cũ phải <= chỉ số mới";
                    }
                }
                else
                {
                    $msg = "Các giá trị phải >= 0";
                }
            }
            else
            {
                $msg = "Không được để trống!";
            }
        }
    ?>
    <div>
        <div style="color: darkred;background-color: #FDDA79;font-size: 30px; width: 30%;text-align: center;">THANH TOÁN TIỀN ĐIỆN</div>
        <div style="background-color: #FEFBD8;width: 30%">
            <form method="post" action="#">
                <table>
                    <tr>
                        <td>Tên chủ hộ:</td>
                        <td><input type="text" name="name" value="<?php if(isset($name)) {echo $name;} ?>"></td>
                    </tr>
                    <tr>
                        <td>Chỉ số cũ:</td>
                        <td><input type="number" step=any name="cs_old" value="<?php if(isset($cs_old)) {echo $cs_old;} ?>"></td>
                        <td>(Kw)</td>
                    </tr>
                    <tr>
                        <td>Chỉ số mới:</td>
                        <td><input type="number" step=any name="cs_new" value="<?php if(isset($cs_new)) {echo $cs_new;} ?>"></td>
                        <td>(Kw)</td>
                    </tr>
                    <tr>
                        <td>Đơn giá:</td>
                        <td><input type="number" step=any name="dg" value="<?php if(isset($dg)) {echo $dg;} ?>"></td>
                        <td>(VNĐ)</td>
                    </tr>
                    <tr>
                        <td style="word-break: normal;">Số tiền thanh toán:</td>
                        <td><input type="text" name="total" readonly name="cv" style="background-color: #FFDAD5;" value="<?php if(isset($total)) {echo $total;} ?>"></td>
                        <td>(VNĐ)</td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align: center;">
                            <input type="submit" name="submit" value="Tính">
                        </td>
                    </tr>
                </table>
            </form>
            <div style="color: red;"><?php if(isset($msg)) {echo $msg;}?></div>
        </div>
    </div>
</body>