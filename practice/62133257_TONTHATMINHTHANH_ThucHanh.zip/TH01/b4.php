<head>
    <title>Kết quả thi đại học</title>
    <style>
        td
        {
            padding-right: 75px;
        }
    </style>
</head>
<body>
    <?php 
        if(isset($_POST["submit"]))
        {
            $toan = $_POST["toan"];
            $ly = $_POST["ly"];
            $hoa = $_POST["hoa"];
            $dc = $_POST["dc"];
            if(is_numeric($toan) && is_numeric($ly) && is_numeric($hoa) && is_numeric($dc))
            {
                if(($toan >= 0 && $toan <= 10) && ($ly >= 0 && $ly <= 10) && ($hoa >= 0 && $hoa <= 10) && ($dc >= 0 && $dc <= 30))
                {
                    $total = round($toan + $ly + $hoa,1);
                    if((($toan != 0) && ($ly != 0) && ($hoa != 0)) && $total >= $dc)
                    {
                        $result = "Đậu";
                    }
                    else
                    {
                        $result = "Rớt";
                    }
                }
                else
                {
                    $msg = "Điểm thi phải >= 0 và <= 10, điểm chuẩn phải >= 0 và <= 30";
                }
            }
            else
            {
                $msg = "Không được để trống!";
            }
        }
    ?>
    <div>
        <div style="color: white;background-color: #E84C81;font-size: 30px; width: 30%;text-align: center;">KẾT QUẢ THI ĐẠI HỌC</div>
        <div style="background-color: #FEE8F8;width: 30%">
            <form method="post" action="#">
                <table>
                    <tr>
                        <td>Toán:</td>
                        <td><input type="number" step=any name="toan" value="<?php if(isset($toan)) {echo $toan;} ?>"></td>
                    </tr>
                    <tr>
                        <td>Lý:</td>
                        <td><input type="number" step=any name="ly" value="<?php if(isset($ly)) {echo $ly;} ?>"></td>
                    </tr>
                    <tr>
                        <td>Hoá:</td>
                        <td><input type="number" step=any name="hoa" value="<?php if(isset($hoa)) {echo $hoa;} ?>"></td>
                    </tr>
                    <tr>
                        <td>Điểm chuẩn:</td>
                        <td><input style="color: red;" type="number" step=any name="dc" value="<?php if(isset($dc)) {echo $dc;} ?>"></td>
                    </tr>
                    <tr>
                        <td>Tổng điểm:</td>
                        <td><input style="background-color: #FFFEE6;" type="text" readonly name="total" value="<?php if(isset($total)) {echo $total;} ?>"></td>
                    </tr>
                    <tr>
                        <td>Kết quả thi:</td>
                        <td><input style="background-color: #FFFEE6;" type="text" readonly name="result" value="<?php if(isset($result)) {echo $result;} ?>"></td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align: center;">
                            <input type="submit" name="submit" value="Xem kết quả">
                        </td>
                    </tr>
                </table>
            </form>
            <div style="color: red;"><?php if(isset($msg)) {echo $msg;}?></div>
        </div>
    </div>
</body>