<html>
    <head>
        <title>Phát sinh mảng và tính toán</title>
    </head>
    <body>
        <?php
            function tao_mang($n)
            {
                $arr = array();
                for($i = 0;$i < $n;$i++)
                {
                    $arr[$i] = rand(0,20);
                }
                return $arr;
            }

            function xuat_mang($arr)
            {
                return implode(" ",$arr);
            }

            function tinh_tong($arr)
            {
                $s = 0;
                for($i = 0;$i < count($arr);$i++)
                {
                    $s += $arr[$i]; 
                }
                return $s;
            }
            
            function tim_min($arr)
            {
                $m = $arr[0];
                for($i = 1;$i < count($arr);$i++)
                {
                    if($m > $arr[$i])
                    {
                        $m = $arr[$i];
                    }
                }
                return $m;
            }

            function tim_max($arr)
            {
                $m = $arr[0];
                for($i = 1;$i < count($arr);$i++)
                {
                    if($m < $arr[$i])
                    {
                        $m = $arr[$i];
                    }
                }
                return $m;
            }

            if(isset($_POST["submit"]))
            {
                if(is_numeric($_POST["n"]))
                {
                    $n = $_POST["n"];
                    if($n > 0)
                    {
                        $arr = tao_mang($n);
                        $mang = xuat_mang($arr);
                        $gtln = tim_max($arr);
                        $gtnn = tim_min($arr);
                        $sum = tinh_tong($arr);
                    }
                    else
                    {
                        $error = "Số lượng phần tử phải > 0!";
                    }
                }
                else
                {
                    $error = "Số lượng phần tử không hợp lệ!";
                }
            }
        ?>
        <div>
            <div style="color: white;background-color: #a80e74;font-size: 25px; width: 45%;text-align: center;text-transform: uppercase;">Phát sinh mảng và tính toán</div>
            <form method="POST">
                <div style="background-color: #fedaf4;width: 45%">
                    <table>
                        <tr>
                            <td>
                                Nhập số phần tử:
                            </td>
                            <td>
                                <input type="number" name="n" value="<?php if(isset($_POST["n"])) {echo $_POST["n"];} ?>">
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="submit" name="submit" value="Phát sinh và tính toán" style="padding: 0px 10px 0px 10px;background-color: yellow;"></td>
                        </tr>
                    </table>
                </div>
                <div style="background-color: #fffbff; font-size:15px;width: 45%">
                    <table>
                        <tr>
                            <td>
                                Mảng:
                            </td>
                            <td>
                                <input type="text" name="mang" style="background-color: #fda8a6;" readonly value="<?php if(isset($mang)) {echo $mang;} ?>">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                GTLN trong mảng:
                            </td>
                            <td>
                                <input type="text" name="gtln" style="background-color: #fda8a6;" readonly value="<?php if(isset($gtln)) {echo $gtln;} ?>">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                GTNN trong mảng:
                            </td>
                            <td>
                                <input type="text" name="gtnn" style="background-color: #fda8a6;" readonly value="<?php if(isset($gtnn)) {echo $gtnn;} ?>">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Tổng mảng:
                            </td>
                            <td>
                                <input type="text" name="sum" style="background-color: #fda8a6;" readonly value="<?php if(isset($sum)) {echo $sum;} ?>">
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3" style="text-align: center">
                                (<b style="color: red">Ghi chú</b> Các phần tử trong mảng sẽ có giá trị từ 0 đến 20)
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3" style="text-align: center">
                                <div style="color: red;"><?php if(isset($error)) {echo $error;}?></div>
                            </td>
                        </tr>
                    </table>
                </div>
            </form>
        </div>
    </body>
</html>