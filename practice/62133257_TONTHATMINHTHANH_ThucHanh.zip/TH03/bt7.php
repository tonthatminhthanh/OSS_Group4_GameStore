<html>
    <head>
        <title>Tính năm âm lịch</title>
    </head>
    <body>
        <?php
            $mang_can = array("Quý","Giáp","Ấp","Bính","Đinh","Mậu","Kỷ","Canh","Tân","Nhâm");
            $mang_chi = array("Hợi","Tý","Sửu","Dần","Mão","Thìn","Tỵ","Ngọ","Mùi","Thân","Dậu","Tuất");
            $mang_hinh = array(
                "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Boar.svg/800px-Boar.svg.png",
                "https://upload.wikimedia.org/wikipedia/commons/thumb/0/04/Rat.svg/800px-Rat.svg.png",
                "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9d/Ox.svg/800px-Ox.svg.png",
                "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Tiger.svg/270px-Tiger.svg.png",
                "https://cdn3.iconfinder.com/data/icons/font-awesome-solid/576/cat-512.png",
                "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Dragon.svg/800px-Dragon.svg.png",
                "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Snake.svg/800px-Snake.svg.png",
                "https://upload.wikimedia.org/wikipedia/commons/thumb/7/76/Horse.svg/800px-Horse.svg.png",
                "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2d/Goat.svg/800px-Goat.svg.png",
                "https://upload.wikimedia.org/wikipedia/commons/thumb/9/96/Monkey_2.svg/270px-Monkey_2.svg.png",
                "https://upload.wikimedia.org/wikipedia/commons/thumb/0/06/Rooster.svg/800px-Rooster.svg.png",
                "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Dog_2.svg/270px-Dog_2.svg.png"
            );

            if(isset($_POST["submit"]))
            {
                if(is_numeric($_POST["year"]) && $_POST["year"] > 0)
                {
                    $year = $_POST["year"];
                    $nam = $year - 3;
                    $can = $nam % 10;
                    $chi = $nam % 12;
                    $res = $mang_can[$can] . " " . $mang_chi[$chi];
                    $res_img = $mang_hinh[$chi];
                }
                else
                {
                    $error = "Năm nhập không hợp lệ";
                }
            }
        ?>
        <div>
            <div style="color: white;background-color: #a2096f;font-size: 25px; width: 25%;text-align: center;text-transform: uppercase;">tính năm âm lịch</div>
                <form method="POST">
                    <div style="background-color: #fcd5ef;width: 25%">
                        <table>
                            <tr>
                                <td>
                                    Năm dương lịch<br>
                                    <input type="number" name="year" value="<?php if(isset($_POST["year"])) {echo $_POST["year"];} ?>">
                                </td>
                                <td>
                                    <input type="submit" name="submit" value="=>">
                                </td>
                                <td>
                                    Năm âm lịch<br>
                                    <input type="text" name="res" readonly value="<?php if(isset($res)) {echo $res;}?>">
                                </td>
                            </tr>
                        </table>
                        <div style="color: red;"><?php if(isset($error)) {echo $error;}?></div>
                        <div style="text-align: center;height: auto;">
                            <?php 
                                if(isset($res_img))
                                {
                                    echo '<img src="'.$res_img.'" width="150px" height="150px">';
                                }
                            ?>
                        </div>
                    </div>
                </form>
        </div>
    </body>
</html>