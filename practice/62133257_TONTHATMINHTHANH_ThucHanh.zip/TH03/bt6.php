<html>
    <head>
        <title>Sắp xếp</title>
    </head>
    <body>
        <?php
            function hoan_vi(&$x,&$y)
            {
                $t = $x;
                $x = $y;
                $y = $t;
            }

            function sap_tang($arr)
            {
                $t = $arr;
                $n = count($arr);
                for($i = 0;$i < $n;$i++)
                {
                    for($j = $i + 1;$j < $n;$j++)
                    {
                        if($t[$i] > $t[$j])
                        {
                            hoan_vi($t[$i],$t[$j]);
                        }
                    }
                }
                return $t;
            }

            function sap_giam($arr)
            {
                $t = $arr;
                $n = count($arr);
                for($i = 0;$i < $n;$i++)
                {
                    for($j = $i + 1;$j < $n;$j++)
                    {
                        if($t[$i] < $t[$j])
                        {
                            hoan_vi($t[$i],$t[$j]);
                        }
                    }
                }
                return $t;
            }

            if(isset($_POST["submit"]))
            {
                if(!empty($_POST["mang"]))
                {
                    $arr = explode(",",$_POST["mang"]);
                    $all_numeric = true;
                    foreach($arr as $item)
                    {
                        if(!is_numeric($item))
                        {
                            $all_numeric = false;
                            break;
                        }
                    }
                    if($all_numeric == true)
                    {
                        $tang_dan = implode(" ",sap_tang($arr));
                        $giam_dan = implode(" ",sap_giam($arr));
                    }
                    else
                    {
                        $error = "Dữ liệu mảng không hợp lệ!";
                    }
                }
                else
                {
                    $error = "Mảng rỗng!";
                }
            }
        ?>
        <div>
            <div style="color: white;background-color: #a2096f;font-size: 25px; width: 35%;text-align: center;text-transform: uppercase;">sắp xếp</div>
                <form method="POST">
                    <div style="background-color: #fcd5ef;width: 35%">
                        <table>
                            <tr>
                                <td>
                                    Nhập mảng:
                                </td>
                                <td>
                                    <input type="text" name="mang" size="35" value="<?php if(isset($_POST["mang"])) {echo $_POST["mang"];} ?>">
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td><input type="submit" name="submit" value="Sắp xếp tăng/giảm" style="padding: 0px 25px 0px 25px;"></td>
                            </tr>
                            <tr>
                                <td colspan="3">
                                    <div style="color: red;">Sau khi sắp xếp:</div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Tăng dần:
                                </td>
                                <td>
                                    <input type="text" name="tang_dan" style="background-color: aquamarine;" size="35" readonly value="<?php if(isset($tang_dan)) {echo $tang_dan;} ?>">
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Giảm dần:
                                </td>
                                <td>
                                    <input type="text" name="giam_dan" style="background-color: aquamarine;" size="35" readonly value="<?php if(isset($giam_dan)) {echo $giam_dan;} ?>">
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div style="background-color: #fff5ff;width: 35%">
                        (<b style="color: red">Ghi chú:</b> Các phần tử trong mảng sẽ cách nhau bằng dấu ",")
                    </div>
                    <div style="color: red;"><?php if(isset($error)) {echo $error;}?></div>
                </form>
        </div>
    </body>
</html>