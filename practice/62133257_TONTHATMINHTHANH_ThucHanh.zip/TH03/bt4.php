<html>
    <head>
        <title>Tìm kiếm</title>
    </head>
    <body>
        <?php
            function tim_kiem($arr,$x)
            {
                $i = 0;
                foreach($arr as $item)
                {
                    if($item == $x)
                    {
                        return $i;
                    }
                    $i++;
                }
                return -1;
            }

            if(isset($_POST["submit"]))
            {
                if(isset($_POST["mang"]) && is_numeric($_POST["n"]))
                {
                    $mang_out = $_POST["mang"];
                    $n = $_POST["n"];
                    $arr = explode(",",$mang_out);
                    $all_numeric = true;
                    foreach($arr as $item)
                    {
                        if(!is_numeric($item))
                        {
                            $all_numeric = false;
                            break;
                        }
                    }
                    if($all_numeric == true)
                    {
                        $i = tim_kiem($arr,$n);
                        if($i != -1)
                            $kq = "Đã tìm thấy ".$n." tại vị trí thứ ".$i." của mảng";
                        else
                            $kq = "Không tìm thấy ".$n." trong mảng";
                    }
                    else
                    {
                        $error = "Dữ liệu mảng không hợp lệ!";
                    }
                }
                else
                {
                    $error = "Dữ liệu mảng hoặc giá trị tìm kiếm không hợp lệ";
                }
            }
        ?>
        <div>
            <div style="color: white;background-color: #339a9e;font-size: 25px; width: 45%;text-align: center;text-transform: uppercase;">tìm kiếm</div>
                <form method="POST">
                    <div style="background-color: #d1ded4;width: 45%">
                        <table>
                            <tr>
                                <td>
                                    Nhập mảng:
                                </td>
                                <td>
                                    <input type="text" name="mang" value="<?php if(isset($_POST["mang"])) {echo $_POST["mang"];} ?>">
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Nhập số cần tìm:
                                </td>
                                <td>
                                    <input type="number" name="n" value="<?php if(isset($_POST["n"])) {echo $_POST["n"];} ?>">
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td><input type="submit" name="submit" value="Tìm kiếm" style="padding: 0px 10px 0px 10px;background-color: #339a9e;"></td>
                            </tr>
                            <tr>
                                <td>Mảng:</td>
                                <td>
                                    <input type="text" name="mang_out" size="45" style="background-color: #fda8a6;" readonly value="<?php if(isset($mang_out)) {echo $mang_out;} ?>">
                                </td>
                            </tr>
                            <tr>
                                <td>Kết quả tìm kiếm:</td>
                                <td>
                                    <input type="text" name="kq" size="45" style="background-color: #fda8a6;" readonly value="<?php if(isset($kq)) {echo $kq;} ?>">
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div style="background-color: #70d4cf;width: 45%">
                        (<b style="color: red">Ghi chú:</b> Các phần tử trong mảng sẽ cách nhau bằng dấu ",")
                    </div>
                    <div style="color: red;"><?php if(isset($error)) {echo $error;}?></div>
            </form>
        </div>
    </body>
</html>