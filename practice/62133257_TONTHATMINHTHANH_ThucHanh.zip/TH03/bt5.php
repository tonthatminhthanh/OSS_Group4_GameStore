<html>
    <head>
        <title>Thay thế</title>
    </head>
    <body>
        <?php
            function thay_the($arr,$cu,$moi)
            {
                $t = $arr;
                for($i = 0;$i < count($t);$i++)
                {
                    if($t[$i] == $cu)
                    {
                        $t[$i] = $moi;
                    }
                }
                return $t;
            }

            if(isset($_POST["submit"]))
            {
                if(!empty($_POST["mang"]))
                {
                    $mang = explode(",",$_POST["mang"]);
                    if(isset($_POST["to_be_replaced"]) && isset($_POST["replacement"]))
                    {
                        $to_be_replaced = $_POST["to_be_replaced"];
                        $replacement = $_POST["replacement"];
                        $new_arr = thay_the($mang,$to_be_replaced,$replacement);
                        $mang_old = implode(" ",$mang);
                        $result = implode(" ",$new_arr);
                    }
                    else
                    {
                        $error = "Giá trị cần thay thế hoặc giá trị thay thế không hợp lệ!";
                    }
                }
                else
                {
                    $error = "Mảng không hợp lệ!";
                }
            }
        ?>
        <div>
            <div style="color: white;background-color: #a2096f;font-size: 25px; width: 45%;text-align: center;text-transform: uppercase;">tìm kiếm</div>
                <form method="POST">
                    <div style="background-color: #fcd5ef;width: 45%">
                        <table>
                            <tr>
                                <td>
                                    Nhập các phần tử:
                                </td>
                                <td>
                                    <input type="text" name="mang" value="<?php if(isset($_POST["mang"])) {echo $_POST["mang"];} ?>">
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Giá trị cần thay thế:
                                </td>
                                <td>
                                    <input type="text" name="to_be_replaced" value="<?php if(isset($_POST["to_be_replaced"])) {echo $_POST["to_be_replaced"];} ?>">
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Giá trị thay thế:
                                </td>
                                <td>
                                    <input type="text" name="replacement" value="<?php if(isset($_POST["replacement"])) {echo $_POST["replacement"];} ?>">
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td><input type="submit" name="submit" value="Thay thế" style="padding: 0px 10px 0px 10px;background-color: yellow;"></td>
                            </tr>
                        </table>
                    </div>
                    <div style="background-color: #fff5ff; font-size:15px;width: 45%">
                        <table>
                            <tr>
                                <td>
                                    Mảng cũ:
                                </td>
                                <td>
                                    <input type="text" name="mang_old" style="background-color: #fda8a6;" readonly value="<?php if(isset($mang_old)) {echo $mang_old;} ?>">
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Mảng sau khi thay thế:
                                </td>
                                <td>
                                    <input type="text" name="result" style="background-color: #fda8a6;" readonly value="<?php if(isset($result)) {echo $result;} ?>">
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div style="background-color: #fff5ff;width: 45%">
                        (<b style="color: red">Ghi chú:</b> Các phần tử trong mảng sẽ cách nhau bằng dấu ",")
                    </div>
                    <div style="color: red;"><?php if(isset($error)) {echo $error;}?></div>
                </form>
            </div>
        </div>
    </body>
</html>