<html>
    <head>
        <title>Tin tức</title>
    </head>
    <body>
        <?php
            require("index.php"); 
        ?>
        <div>Đây là trang thông tin được cập nhật đầy đủ và chi tiết nhất.</div>
    </body>
</html>