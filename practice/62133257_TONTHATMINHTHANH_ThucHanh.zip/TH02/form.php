<html>
    <head>
        <title>Form</title>
        <meta charset="utf-8">
    </head>
    <body>
        <div>
            <h3><b style="text-transform: capitalize;">Enter your information</b></h5>
            <form method="post" action="#">
                <table>
                    <tr>
                        <td>Fullname</td>
                        <td><input type="text" name="fullname"></td>
                    </tr>
                    <tr>
                        <td>Address</td>
                        <td><input type="text" name="address"></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td><input type="tel" name="phone"></td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td>
                            <input type="radio" name="gender" value="0" checked> Nam
                            <input type="radio" name="gender" value="1"> Nữ
                        </td>
                    </tr>
                    <tr>
                        <td>Country</td>
                        <td>
                            <select name="country">
                                <option value="Việt Nam">Việt Nam</option>
                                <option value="Đức">Đức</option>
                                <option value="Hoa Kỳ">Hoa Kỳ</option>
                                <option value="Nhật Bản">Nhật Bản</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Study</td>
                        <td>
                            <input type="checkbox" name="study" value="php_sql"> PHP & MySQL
                            <input type="checkbox" name="study" value="aspnet"> ASP.NET
                            <input type="checkbox" name="study" value="ccna"> CCNA
                            <input type="checkbox" name="study" value="secplus"> Security+
                        </td>
                    </tr>
                    <tr>
                        <td>Note</td>
                        <td>
                            <textarea name="note"></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align: center;">
                            <input type="submit" name="submit" value="Gửi">
                            <input type="reset" value="Hủy">
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </body>
</html>