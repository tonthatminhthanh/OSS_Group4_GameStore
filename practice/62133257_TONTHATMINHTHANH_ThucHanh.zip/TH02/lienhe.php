<html>
    <head>
        <title>Liên hệ</title>
    </head>
    <body>
        <?php
            require("index.php"); 
        ?>
        <div>Mọi chi tiết xin liên hệ với chúng tôi thông qua form liên hệ thuộc website.</div>
    </body>
</html>