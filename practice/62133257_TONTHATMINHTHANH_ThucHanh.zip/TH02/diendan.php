<html>
    <head>
        <title>Diễn đàn</title>
    </head>
    <body>
        <?php
            require("index.php"); 
        ?>
        <div>Đây là không gian thảo luận về tất cả cả các vấn đề về công nghệ và giáo dục.</div>
    </body>
</html>