<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="utf-8">
        <style>
            body 
            {
                margin: 0
            }

            #header {
                display: flex;
                text-align: center;
                width: 100%;
                background-color: rgb(121, 199, 255);
                height: 100px;
                align-items: center;
                margin: 0;
                color: white;
            }

            #header p {
                display: inline-block;
                margin: 0;
                font-size: larger;
                font-weight: bold;
                font-style: italic;
                text-shadow: 2px 2px black;
                padding: 20px;
            }

            #header img
            {
                display: inline-block;
                max-height: 80px;
                max-width: 80px;
                border: #ffffff solid;
                border-radius: 100%;
                flex-basis: 40%;
                margin-left: 10px;
            }

            #navbar
            {
                display: block;
                width: 100%;
                margin: 0;
                background-color: #33ccff;
            }

            #navbar ul
            {
                padding: 0;
                list-style: none;
                margin: 0;
            }

            #navbar li
            {
                display: inline-block;
                margin-left: 20px;
            }

            #navbar a
            {
                color: white;
                text-decoration: none;
                font-size: 18px;
            }

            #navbar li:hover
            {
                background-color: #ff99cc;
            }   

            #navbar li:active a
            {
                text-shadow: 2px 2px black;
            }
        </style>
    </head>
    <body>
        <div id="page_header">
            <div id="header">
                <img src="https://github.com/tonthatminhthanh.png">
                <p>Thành's website</p>
            </div>
            <div id="navbar">
                <ul>
                    <li><a href="trangchu.php">Trang chủ</a</li>
                    <li><a href="gioithieu.php">Giới thiệu</a></li>
                    <li><a href="tintuc.php">Tin tức</a></li>
                    <li><a href="lienhe.php">Liên hệ</a></li>
                    <li><a href="diendan.php">Diễn đàn</a></li>
                </ul>
            </div>
        </div>
    </body>
</html>