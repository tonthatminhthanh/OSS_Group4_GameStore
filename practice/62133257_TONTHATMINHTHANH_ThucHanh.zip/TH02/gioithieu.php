<html>
    <head>
        <title>Giới thiệu</title>
    </head>
    <body>
        <?php
            require("index.php"); 
        ?>
        <div>Website được ra đời vào ngày 01/06/2018</div>
    </body>
</html>