<html>
    <head>
        <title>Tính tổng dãy số</title>
    </head>
    <body>
        <?php
            if(isset($_GET["submit"]))
            {
                if(isset($_GET["inp"]))
                {
                    $dayso = $_GET["inp"];
                    $arr = explode(",",$dayso);

                    $res = 0;
                    for($i = 0;$i < count($arr);$i++)
                    {
                        if(!is_numeric($arr[$i]))
                        {
                            $error = "Dãy số không hợp lệ";
                            break;
                        }
                        $res += $arr[$i];
                    }
                }
            }
        ?>
        <div>
            <div style="color: white;background-color: #319393;font-size: 30px; width: 30%;text-align: center;">NHẬP VÀ TÍNH TRÊN DÃY SỐ</div>
            <div style="background-color: #ccd9cf;width: 30%">
                <form method="get">
                    <table>
                        <tr>
                            <td>
                                Nhập dãy số:
                            </td>
                            <td>
                                <input size="35" type="text" name="inp" value="<?php if(isset($_GET["inp"])) {echo $_GET["inp"];}?>">
                            </td>
                            <td style="color: red">
                                (*)
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3" style="text-align: center">
                                <input type="submit" value="Tổng dãy số" name="submit">
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Tổng dãy số:
                            </td>
                            <td>
                                <input style="background-color: #c4fb98;"type="text" value="<?php if(is_numeric($res) && !isset($error)) {echo $res;}?>">
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3" style="text-align: center">
                                <b style="color: red">(*)</b> Các số được nhập cách nhau bằng dấu ","
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3" style="text-align: center">
                                <div style="color: red;"><?php if(isset($error)) {echo $error;}?></div>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </body>
</html>