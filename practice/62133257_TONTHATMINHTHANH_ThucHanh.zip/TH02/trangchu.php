<html>
    <head>
        <title>Trang chủ</title>
    </head>
    <body>
        <?php
            require("index.php"); 
        ?>
        <div>Chào mừng các bạn đến với website của chúng tôi.</div>
    </body>
</html>