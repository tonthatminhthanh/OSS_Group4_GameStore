<html>
<head>
    <title>Kết quả</title>
</head>
<body>
    <?php 
        if(isset($_GET["submit"]))
        {
            $n1 = $_GET["first_num"];
            $n2 = $_GET["second_num"];
            $op = $_GET["operator"];
            $get_header = "operator=" . $op . "&" . "first_num=" . $n1. "&" . "second_num=" . $n2;
            if(is_numeric($n1) && is_numeric($n2))
            {
                switch($op) {
                    case "+":
                        $kq = $n1 + $n2;
                        $op_txt = "Cộng";
                        break;
                    case "-":
                        $kq = $n1 - $n2;
                        $op_txt = "Trừ";
                        break;
                    case "*":
                        $kq = $n1 * $n2;
                        $op_txt = "Nhân";
                        break;
                    case "/":
                        $op_txt = "Chia";
                        if($n2 != 0)
                        {
                            $kq = $n1 / $n2;
                        }
                        else
                        {
                            $error_message = "Không thể chia cho 0!";
                            header("Location: bt6.php?error=" . $error_message . "&" . $get_header);
                            exit;
                        }
                        break;
                }
            }
            else
            {
                $error_message = "Dữ liệu không hợp lệ!";
                header("Location: bt6.php?error=" . $error_message . "&" . $get_header);
                exit;
            }
        }
    ?>
    <div style="margin: auto;width: 25%">
        <h3>PHÉP TÍNH TRÊN HAI SỐ</h3>
        <table>
            <tr>
                <td>Chọn phép tính:</td>
                <td style="color: red"><?php if(isset($op_txt)) {echo $op_txt;} ?></td>
            </tr>
            <tr>
                <td>Số 1:</td>
                <td><input type="text" readonly value="<?php if(isset($n1)) {echo $n1;} ?>"></td>
            </tr>
            <tr>
                <td>Số 2:</td>
                <td><input type="text" readonly value="<?php if(isset($n2)) {echo $n2;} ?>"></td>
            </tr>
            <tr>
                <td>Kết quả:</td>
                <td><input type="text" style="<?php if(!is_numeric($kq)) {echo 'color: red';} ?>" readonly value="<?php if(isset($kq)) {echo $kq;} ?>"></td>
            </tr>
            <tr>
                <td colspan="2">
                    <a href="<?php echo "bt6.php?" . $get_header?>" >Quay lại</a>
                </td>
            </tr>
        </table>
    </div>
</body>
</html>