<head>
    <title>Nhập liệu</title>
</head>
<body>
    <div style="margin: auto;width: 25%">
        <h3>PHÉP TÍNH TRÊN HAI SỐ</h3>
        <form method="get" action="bt6_kq.php">
            <table>
                <tr>
                    <td>
                        Chọn phép tính:
                    </td>
                    <td>
                        <input type="radio" name="operator" value="+" checked> Cộng
                        <input type="radio" name="operator" value="-"> Trừ
                        <input type="radio" name="operator" value="*"> Nhân
                        <input type="radio" name="operator" value="/"> Chia
                    </td>
                </tr>
                <tr>
                    <td>Số thứ nhất:</td>
                    <td><input type="number" step="any" name="first_num" value="<?php if(isset($_GET["first_num"])) {echo $_GET["first_num"];} ?>"></td>
                </tr>
                <tr>
                    <td>Số thứ hai:</td>
                    <td><input type="number" step="any" name="second_num" value="<?php if(isset($_GET["second_num"])) {echo $_GET["second_num"];}?>"></td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Tính">
                    </td>
                </tr>
            </table>
        </form>
        <div style="color: red;"><?php if(isset($_GET["error"])) {echo $_GET["error"];}?></div>
    </div>
</body>