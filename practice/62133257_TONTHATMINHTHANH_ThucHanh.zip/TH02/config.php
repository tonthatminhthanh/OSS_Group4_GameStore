<?php
    if(!isset($_POST["submit"]))
    {
        require("form.php");
    }
?>
<html>
    <head>
        <title>Config</title>
    </head>
    <body>
        <?php
            if(isset($_POST["submit"]))
            {
                if($_POST["gender"] == 0)
                {
                    $gender = "Nữ";
                }
                else
                {
                    $gender = "Nam";
                }
                echo "
                <p>Bạn đã nhập thành công, dưới đây là thông tin bạn đã nhập:</p>
                <p>Họ tên: ".$_POST["fullname"]."</p>
                <p>Address: ".$_POST["address"]."</p>
                <p>Phone: ".$_POST["phone"]."</p>
                <p>Gender: ".$gender."</p>
                <p>Country: ".$_POST["country"]."</p>
                <p>Note: ".$_POST["note"]."</p>
            ";
            }
        ?>
    </body>
</html>