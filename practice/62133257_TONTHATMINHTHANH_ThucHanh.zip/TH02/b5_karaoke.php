<head>
    <title>Tính tiền Karaoke</title>
    <style>
        td
        {
            padding-right: 10px;
        }
    </style>
</head>
<body>
    <?php 
        if(isset($_POST["submit"]))
        {
            $start_time = $_POST["bd"];
            $end_time = $_POST["kt"];

            if(isset($start_time) && isset($end_time))
            {
                $bd = explode(":",$start_time);
                $kt = explode(":",$end_time);
                if(($bd[0] >= 0 && $bd[0] <= 24) && ($kt[0] >= 0 && $kt[0] <= 24))
                {
                    if($kt[0] == 12)
                    {
                        $kt[0] = 24;
                    }
                    if($bd[0] == 12)
                    {
                        $bd[0] = 24;
                    }
                    $sum_start_minute = $bd[0] * 60 + $bd[1];
                    $sum_end_minute = $kt[0] * 60 + $kt[1];
                    if($sum_end_minute > $sum_start_minute)
                    {
                        if(($bd[0] >= 10) && ($bd[0] < 17))
                        {
                            $kq = ($sum_end_minute - $sum_start_minute) * 20000 / 60;
                        }
                        else if(($bd[0] >= 17) && ($bd[0] < 24))
                        {
                            $kq = ($sum_end_minute - $sum_start_minute) * 45000 / 60;
                        }
                        else
                        {
                            $kq = "Giờ nghỉ!";
                        }
                    }
                    else
                    {
                        $msg = "Giờ kết thúc phải > giờ bắt đầu ";
                    }
                }
                else
                {
                    $msg = "Giờ phải >= 0 và <= 24!";
                }
            }
        }
    ?>
    <div>
        <div style="color: white;background-color: #008B8E;font-size: 30px; width: 25%;text-align: center;">TÍNH TIỀN KARAOKE</div>
        <div style="background-color: #03B1B2;width: 25%">
            <form method="post" action="#">
                <table>
                    <tr>
                        <td>Giờ bắt đầu:</td>
                        <td><input type="time" name="bd" value="<?php if(isset($start_time)) {echo $start_time;} ?>"></td>
                        <td>(hh:mm)</td>
                    </tr>
                    <tr>
                        <td>Giờ kết thúc:</td>
                        <td><input type="time" name="kt" value="<?php if(isset($end_time)) {echo $end_time;} ?>"></td>
                        <td>(hh:mm)</td>
                    </tr>
                    <tr>
                        <td>Tiền thanh toán:</td>
                        <td><input style="background-color: #FFFEE6;color: green" type="text" name="kq" readonly value="<?php if(isset($kq)) {echo $kq;} ?>"></td>
                        <td>(VNĐ)</td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align: center;">
                            <input type="submit" name="submit" value="Tính tiền">
                            <input type="reset" value="Nhập lại">
                        </td>
                    </tr>
                </table>
            </form>
            <div style="color: red;"><?php if(isset($msg)) {echo $msg;}?></div>
        </div>
    </div>
</body>