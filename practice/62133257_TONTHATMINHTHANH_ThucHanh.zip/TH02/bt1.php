<html>
    <head>
        <title>Bài 1</title>
    </head>
    <body>
        <form method="get">
            <input placeholder="Nhập n" type="number" name="n" value="<?php if(isset($_GET["n"])) { echo $_GET["n"]; }?>">
            <input type="submit" value="Thực hiện" name="submit">
        </form>
        <?php 
            if(is_numeric($_GET["n"]) && $_GET["n"] > 0)
            {
                $n = $_GET["n"];

                $arr = array();
                
                for($i = 0;$i < $n;$i++)
                {
                    array_push($arr,rand(-100,200)*rand(-1,1));
                }

                echo "Các phần tử trong mảng: ";

                for($i = 0;$i < $n;$i++)
                {
                    echo $arr[$i] . " ";
                }

                $count = 0;

                for($i = 0;$i < $n;$i++)
                {
                    if($arr[$i] % 2 == 0)
                    {
                        $count++;
                    }
                }

                echo "<br>Số lượng phần tử chẵn: " . $count;

                $count = 0;

                for($i = 0;$i < $n;$i++)
                {
                    if($arr[$i] < 100)
                    {
                        $count++;
                    }
                }

                echo "<br>Số lượng phần tử nhỏ hơn 100: " . $count;

                $sum = 0;

                for($i = 0;$i < $n;$i++)
                {
                    if($arr[$i] < 0)
                    {
                        $sum += $arr[$i];
                    }
                }

                echo "<br>Tổng các số có giá trị âm: " . $sum;
                
                echo "<br>Vị trí các phần tử == 0: ";
                for($i = 0;$i < $n;$i++)
                {
                    if($arr[$i] == 0)
                    {
                        echo $i. " ";
                    }
                }
                sort($arr);
                
                echo "<br>Các phần tử trong mảng (tăng dần): ";
                for($i = 0;$i < $n;$i++)
                {
                    echo $arr[$i] . " ";
                }
            }
            else
            {
                echo "<p style='color: red'>n phải lớn hơn 0</p>";
            }
        ?>
    </body>
</html>